import sys
import subprocess

packages = ["pandas","numpy","statsmodels","scikit-learn","matplotlib"
,"pmdarima"]

for pkg in packages:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg])