import pandas as pd
import numpy as np
import datetime

def text_to_csv(file_location):
    file_location = file_location
    cursor = open(file_location,"r",encoding="utf-8")
    content = cursor.readlines()
    data = []
    for line in content:
        data_lines = line.split(",")
        data_lines = data_lines[0:-1]
        company = data_lines[0]
        #date_time = datetime.datetime.fromisoformat(data_lines[1])
        #print(date_time)
        date = str(datetime.datetime.strptime(data_lines[1],"%Y%m%d").date())
        time = str(datetime.datetime.strptime(data_lines[2],"%H:%M").time())
        openn = float(data_lines[3])
        high = float(data_lines[4])
        low = float(data_lines[5])
        close = float(data_lines[6])
        volume = int(data_lines[7])
        data.append([company,date,time,openn,high,low,close,volume])
    data = np.array(data)
    columns = ['ScriptName','Date','TimeStamp','Open','High','Low','Close','Volume']
    data = pd.DataFrame(data,columns=columns)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() >= datetime.time(9,30,0))
    data = data.loc[demo_data].reset_index(drop=True)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() <= datetime.time(15,0,0))
    data = data.loc[demo_data].reset_index(drop=True)
    file_location = file_location.split(".")
    data.to_csv('{}.{}'.format(file_location[0],"csv"),index=False)
    return pd.read_csv('{}.{}'.format(file_location[0],"csv"))