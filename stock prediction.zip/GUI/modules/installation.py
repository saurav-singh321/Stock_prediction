#import pip
import warnings
warnings.filterwarnings("ignore")
import sys
import subprocess

'''def install(package):
    try:
        if hasattr(pip, 'main'):
            pip.main(['install', package])
        else:
            pip._internal.main(['install', package])
        return "Successful"
    except Exception:
        return "Unsuccessful"'''

def install(package):
    try:
        subprocess.call([ 'pip', 'install', package])
        return "Successful"
    except:
        return "Unsuccessful"

# Example
if __name__ == '__main__':
    result = install('pandas')
    print(result)
