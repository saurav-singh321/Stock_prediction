import pandas as pd
import numpy as np
import datetime
import plotly.graph_objects as go

def text_to_csv(file_location):
    file_location = file_location
    cursor = open(file_location,"r",encoding="utf-8")
    content = cursor.readlines()
    data = []
    for line in content:
        data_lines = line.split(",")
        data_lines = data_lines[0:-1]
        company = data_lines[0]
        #date_time = datetime.datetime.fromisoformat(data_lines[1])
        #print(date_time)
        date = str(datetime.datetime.strptime(data_lines[1],"%Y%m%d").date())
        time = str(datetime.datetime.strptime(data_lines[2],"%H:%M").time())
        openn = float(data_lines[3])
        high = float(data_lines[4])
        low = float(data_lines[5])
        close = float(data_lines[6])
        volume = int(data_lines[7])
        data.append([company,date,time,openn,high,low,close,volume])
    data = np.array(data)
    columns = ['ScriptName','Date','TimeStamp','Open','High','Low','Close','Volume']
    data = pd.DataFrame(data,columns=columns)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() >= datetime.time(9,30,0))
    data = data.loc[demo_data].reset_index(drop=True)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() <= datetime.time(15,0,0))
    data = data.loc[demo_data].reset_index(drop=True)
    file_location = file_location.split(".")
    data.to_csv('{}.{}'.format(file_location[0],"csv"),index=False)
    return pd.read_csv('{}.{}'.format(file_location[0],"csv"))

def range_selector(file_location,duration=0):
    if duration == 0:
        new_data = text_to_csv(file_location)
        per_change = [0-round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5) if round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5)<0 else round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5) for index in range(len(new_data))]
        #print(per_change)

        new_data["PerChange"] = per_change

        arrow_list = []
        counter = 0
        for i in new_data["PerChange"].tolist():
            if i > 0.2:
                arrow = dict(x=new_data["TimeStamp"].values[counter],y=new_data["High"].values[counter],xref="x",yref="y",text="{}".format(round(new_data["PerChange"][counter],2)),
                             ax=20,ay=-30,arrowhead=3,arrowwidth=1.5,arrowcolor='rgb(255,51,0)')
                arrow_list.append(arrow)
                counter += 1
            else:
                counter += 1
        return new_data,arrow_list

    else:
        data = text_to_csv(file_location)
        print(len(data))
        #print("Loops: {}   Data Left: {}".format(len(data)//duration,len(data)%duration))
        count = 0
        data_vals = []
        cols = list(data.columns)
        #print(cols)
        for loops in range(len(data)//duration):
            timestamp = []
            openn = []
            high = []
            low = []
            close = []
            volume = []
            for index in range(count,count+duration):
                company = data["ScriptName"][index]
                date = data["Date"][index]
                timestamp.append(data["TimeStamp"][index])
                openn.append(data["Open"][index])
                high.append(data["High"][index])
                low.append(data["Low"][index])
                close.append(data["Close"][index])
                volume.append(data["Volume"][index])
            count += duration
            #print(data["TimeStamp"][count])
            #print("+++++++++ ITERATION {} ++++++++".format(loops))
            #print(timestamp)
            #print(openn)
            #print(high)
            #print(low)
            #print(close)
            #print("ScriptName:{} - Date:{} - TimeStamp:{} - Open:{} - High:{} - Low:{} - Close:{} - Volume:{}".format(company,date,timestamp[0],openn[0],max(high),min(low),close[-1],sum(volume)))
            vals = [company,date,timestamp[0],openn[0],max(high),min(low),close[-1],sum(volume)]
            data_vals.append(vals)
        new_data = pd.DataFrame(data_vals,columns=cols)
        #print(len(new_data))

        per_change = [0-round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5) if round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5)<0 else round(((new_data["Open"][index] - new_data["Close"][index])/new_data["Open"][index])*100,5) for index in range(len(new_data))]
        #print(per_change)

        new_data["PerChange"] = per_change

        arrow_list = []
        counter = 0
        for i in new_data["PerChange"].tolist():
            if i > 0.2:
                arrow = dict(x=new_data["TimeStamp"].values[counter],y=new_data["High"].values[counter],xref="x",yref="y",text="{}".format(round(new_data["PerChange"][counter],2)),
                             ax=20,ay=-30,arrowhead=3,arrowwidth=1.5,arrowcolor='rgb(255,51,0)')
                arrow_list.append(arrow)
                counter += 1
            else:
                counter += 1
        return new_data,arrow_list

def show_fig(new_data,arrow_list):
    fig = go.Figure(data = [go.Candlestick(
        x = new_data['TimeStamp'],
        open = new_data['Open'],
        high = new_data['High'],
        low = new_data['Low'],
        close = new_data['Close'],
        increasing_line_color = 'green',
        decreasing_line_color = 'red'
        )])

    fig.update_layout(
        title = new_data["ScriptName"][0],
        yaxis_title = "Stocks",
        xaxis_title = "Time Duration in Hours:Minutes:Seconds",
        annotations=arrow_list
        )

    fig.show()

#file_location = input("Enter Location: ")
#duration = int(input("Enter the Range (Default 0): "))

#new_data,arrow_list = range_selector(file_location,duration)
