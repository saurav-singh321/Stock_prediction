import pandas as pd
import numpy as np
import datetime
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error as mse
from sklearn.metrics import accuracy_score as score
from pandas.plotting import autocorrelation_plot
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_pacf
import os
import warnings
from pmdarima.arima import auto_arima
from pmdarima.pipeline import Pipeline
from pmdarima.preprocessing import BoxCoxEndogTransformer
warnings.filterwarnings("ignore")

def text_to_csv(file_location):
    file_location = file_location
    cursor = open(file_location,"r",encoding="utf-8")
    content = cursor.readlines()
    data = []
    for line in content:
        data_lines = line.split(",")
        data_lines = data_lines[0:-1]
        company = data_lines[0]
        #date_time = datetime.datetime.fromisoformat(data_lines[1])
        #print(date_time)
        date = str(datetime.datetime.strptime(data_lines[1],"%Y%m%d").date())
        time = str(datetime.datetime.strptime(data_lines[2],"%H:%M").time())
        openn = float(data_lines[3])
        high = float(data_lines[4])
        low = float(data_lines[5])
        close = float(data_lines[6])
        volume = int(data_lines[7])
        data.append([company,date,time,openn,high,low,close,volume])
    data = np.array(data)
    columns = ['ScriptName','Date','TimeStamp','Open','High','Low','Close','Volume']
    data = pd.DataFrame(data,columns=columns)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() >= datetime.time(9,30,0))
    data = data.loc[demo_data].reset_index(drop=True)
    demo_data = []
    for index in range(len(data)):
        demo_data.append(datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time() <= datetime.time(15,0,0))
    data = data.loc[demo_data].reset_index(drop=True)
    file_location = file_location.split(".")
    data.to_csv('{}.{}'.format(file_location[0],"csv"),index=False)
    return pd.read_csv('{}.{}'.format(file_location[0],"csv"))

def selector(folder_name,scriptname,time_from,time_to,month,n_of_days):
    files = os.listdir(folder_name)
    #print(files)
    month_files = os.listdir('{}/{}'.format(folder_name,month))
    #print(sorted(month_files))
    #print(month_files)
    d = []
    t = []
    c = []
    sub_data = []
    for file_index in range(0,n_of_days):
        script = "{}.txt".format(scriptname.upper())
        data = text_to_csv("{}/{}/{}/{}".format(folder_name,month,month_files[file_index],script))
        #print(data.head())
        
        for index in range(len(data)):
            data['TimeStamp'][index] = datetime.datetime.strptime(data['TimeStamp'][index],"%H:%M:%S").time()
        
        for i in range(len(data)):
            #print(i)
            if data['TimeStamp'][i] == datetime.datetime.strptime(time_from,"%H:%M:%S").time():
                data_index = i
                #print(i,data['TimeStamp'][i])
                break
        value_index = data_index
        while(data['TimeStamp'][value_index] != datetime.datetime.strptime(time_to,"%H:%M:%S").time()):
            #print(data['TimeStamp'][value_index])
            d.append(datetime.datetime.strptime(data['Date'][value_index],"%Y-%m-%d").date())
            t.append(data['TimeStamp'][value_index])
            c.append(data['Close'][value_index])
            value_index += 1
    #print(d)
    #print(t)
    #print(c)
    #print(len(d),len(t),len(c))
    return d,t,c,files,month_files

def datasetcreation(d,t,c):
    dt = [pd.datetime.combine(d[i],t[i]) for i in range(len(d))]
    data = pd.DataFrame({"DateTime":dt,"Close":c})
    return data

def arima_model_prediction(data):
    train_length = len(data)-15
    train_data = data[0:train_length]
    test_data = data[train_length:]
    testing_data = test_data['Close'].values
    test_datetime = data[train_length:]['DateTime']
    training_data = train_data['Close'].values
    history = [x for x in training_data]
    model_pred = []
    N = len(testing_data)
    for point_time in range(N):
        model = auto_arima(history,start_p=1,
                       max_p=7,start_q=1,max_q=20,
                       start_P=1,
                       max_P=7,start_Q=1,max_Q=20,
                       error_action='ignore',m=7,
                       stepwise=True,seasonal=True, 
                       suppress_warnings=True,random_state=0,
                      n_fits=15)
        #print(model.predict(n_periods=1))
        output = model.predict(n_periods=1)
        #print(output[0][0])
        yhat = output[0]
        model_pred.append(yhat)
        true_test_value = testing_data[point_time]
        history.append(true_test_value)
        print("------ Completed: {}% ------".format(round((point_time/len(testing_data)*100),0)))
    #print(model_pred)
    #print(testing_data)
    return model.order,model_pred,testing_data,test_datetime

def show_corr(data):
    fig = plt.figure()
    fig.set_figheight(20)
    fig.set_figwidth(40)
    autocorrelation_plot(data[:50])
    plt.xticks(range(0,50))
    plt.show()

def show_pcaf(data):
    plot_pacf(time_data,lags=(len(data)//2)-1)
    plt.show()

def report(folder_name,scrpt_name,from_time,to_time,month_name,no_of_files):
    d,t,c,files,month_files=selector(folder_name,scrpt_name,from_time,to_time,month_name,no_of_files)
    data = datasetcreation(d,t,c)
    order,model_pred,test_data,test_datetime = arima_model_prediction(data)
    report_script = [scrpt_name.upper() for i in range(len(test_datetime))]
    date_files = os.listdir('{}/{}'.format(folder_name,month_name.upper()))
    dates = [date_files[i] for i in range(no_of_files)]
    report_from_dates = [dates[0] for i in range(len(test_datetime))]
    report_to_dates = [dates[-1] for i in range(len(test_datetime))]
    report_from_time = [from_time for i in range(len(test_datetime))]
    report_to_time = [to_time for i in range(len(test_datetime))]
    report_test_datetime = [i for i in test_datetime]
    report_test_values = [i for i in test_data]
    report_pred_values = [round(i,1) for i in model_pred]
    report_p = [order[0] for i in range(len(test_datetime))]
    report_d = [order[1] for i in range(len(test_datetime))]
    report_q = [order[2] for i in range(len(test_datetime))]
    report_mse = [mse(test_data,model_pred) for i in range(len(test_datetime))]
    report_model = ["AUTO ARIMA MODEL" for i in range(len(test_datetime))]
    report_candle_size = [1 for i in range(len(test_datetime))]
    report_data = pd.DataFrame({'ScriptName':report_script,'FromDate':report_from_dates,'ToDate':report_to_dates,
                               'FromTime':report_from_time,'ToTime':report_to_time,'DateTime':report_test_datetime,
                               'Actual':report_test_values,'Predicted':report_pred_values,'P (Lag)':report_p,'D (Difference)':report_d,
                              'Q (Avg Window)':report_q,'Mean Squared Error':report_mse,'ModelName':report_model,'CandleSize':report_candle_size})
    if not os.path.exists("reports"):
        os.mkdir("reports")
    report_data.to_csv('reports/{}_{}_{}_AutoArima.{}'.format(scrpt_name.upper(),dates[-1],to_time[:2],"csv"),index=False)
    return report_data,data
