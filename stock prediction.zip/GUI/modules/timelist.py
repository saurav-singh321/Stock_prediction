def time_list():
    timelist = []
    for h in range(9,15):
        temp = ""
        if h<10:
            temp2 = temp+"0"+str(h)
        else:
            temp2 = temp+str(h)
        for m in range(60):
            if m<10:
                temp3 = temp2+":0"+str(m)
            else:
                temp3 = temp2+":"+str(m)
            for s in range(1):
                if s<10:
                    temp4 = temp3+":0"+str(s)
                else:
                    temp4 = temp3+":"+str(s)
                timelist.append(temp4)
    return timelist
