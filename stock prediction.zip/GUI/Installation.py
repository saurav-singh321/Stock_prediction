from tkinter import *
from tkinter import ttk
from modules.installation import install

def module_install(package,label):
    label.config(text="Installing")
    result = install(package)
    label.config(text=result)

root = Tk()
root.title("Stock Market Report Generation")
root.geometry('1000x370+200+200')
root.resizable(0,0)

root.option_add('*tearOff', False)
menubar = Menu(root)
root.config(menu = menubar)
file = Menu(menubar)
edit = Menu(menubar)
help_ = Menu(menubar)

menubar.add_cascade(menu = file, label = 'File')
menubar.add_cascade(menu = edit, label = 'Edit')
menubar.add_cascade(menu = help_, label = 'Help')

pandas = ttk.Labelframe(root,height=60,width=350,text='Pandas')
pandas.place(x=60,y=10)
pandas_label = ttk.Label(pandas,text="Please Install...")
pandas_label.place(x=10,y=10)
ttk.Button(pandas,text="Install",command=lambda: module_install("pandas",pandas_label)).place(x=140,y=6)

numpy = ttk.Labelframe(root,height=60,width=250,text='Numpy')
numpy.place(x=360,y=10)
numpy_label = ttk.Label(numpy,text="Please Install...")
numpy_label.place(x=10,y=10)
ttk.Button(numpy,text="Install",command=lambda: module_install("numpy",numpy_label)).place(x=140,y=6)

plotly = ttk.Labelframe(root,height=60,width=250,text='Plotly')
plotly.place(x=660,y=10)
plotly_label = ttk.Label(plotly,text="Please Install...")
plotly_label.place(x=10,y=10)
ttk.Button(plotly,text="Install",command=lambda: module_install("plotly",plotly_label)).place(x=140,y=6)

matplotlib = ttk.Labelframe(root,height=60,width=250,text='Matplotlib')
matplotlib.place(x=60,y=80)
matplotlib_label = ttk.Label(matplotlib,text="Please Install...")
matplotlib_label.place(x=10,y=10)
ttk.Button(matplotlib,text="Install",command=lambda: module_install("matplotlib",matplotlib_label)).place(x=140,y=6)

cefpython3 = ttk.Labelframe(root,height=60,width=250,text='Cefpython3')
cefpython3.place(x=360,y=80)
cefpython3_label = ttk.Label(cefpython3,text="Please Install...")
cefpython3_label.place(x=10,y=10)
ttk.Button(cefpython3,text="Install",command=lambda: module_install("cefpython3",cefpython3_label)).place(x=140,y=6)

pandastable = ttk.Labelframe(root,height=60,width=250,text='Pandastable')
pandastable.place(x=660,y=80)
pandastable_label = ttk.Label(pandastable,text="Please Install...")
pandastable_label.place(x=10,y=10)
ttk.Button(pandastable,text="Install",command=lambda: module_install("pandastable",pandastable_label)).place(x=140,y=6)

platform = ttk.Labelframe(root,height=60,width=250,text='Platform')
platform.place(x=60,y=150)
platform_label = ttk.Label(platform,text="Please Install...")
platform_label.place(x=10,y=10)
ttk.Button(platform,text="Install",command=lambda: module_install("platform",platform_label)).place(x=140,y=6)

pillow = ttk.Labelframe(root,height=60,width=250,text='Pillow')
pillow.place(x=360,y=150)
pillow_label = ttk.Label(pillow,text="Please Install...")
pillow_label.place(x=10,y=10)
ttk.Button(pillow,text="Install",command=lambda: module_install("pillow",pillow_label)).place(x=140,y=6)

statsmodel = ttk.Labelframe(root,height=60,width=250,text='Statsmodel')
statsmodel.place(x=660,y=150)
statsmodel_label = ttk.Label(statsmodel,text="Please Install...")
statsmodel_label.place(x=10,y=10)
ttk.Button(statsmodel,text="Install",command=lambda: module_install("statsmodel",statsmodel_label)).place(x=140,y=6)

scipy = ttk.Labelframe(root,height=60,width=250,text='Scipy')
scipy.place(x=60,y=220)
scipy_label = ttk.Label(scipy,text="Please Install...")
scipy_label.place(x=10,y=10)
ttk.Button(scipy,text="Install",command=lambda: module_install("scipy",scipy_label)).place(x=140,y=6)

sklearn = ttk.Labelframe(root,height=60,width=250,text='Scikit Learn')
sklearn.place(x=360,y=220)
sklearn_label = ttk.Label(sklearn,text="Please Install...")
sklearn_label.place(x=10,y=10)
ttk.Button(sklearn,text="Install",command=lambda: module_install("scikit-learn",sklearn_label)).place(x=140,y=6)

pmdarima = ttk.Labelframe(root,height=60,width=250,text='Pmdarima')
pmdarima.place(x=660,y=220)
pmdarima_label = ttk.Label(pmdarima,text="Please Install...")
pmdarima_label.place(x=10,y=10)
ttk.Button(pmdarima,text="Install",command=lambda: module_install("pmdarima",pmdarima_label)).place(x=140,y=6)

psutil = ttk.Labelframe(root,height=60,width=250,text='Psutil')
psutil.place(x=60,y=290)
psutil_label = ttk.Label(psutil,text="Please Install...")
psutil_label.place(x=10,y=10)
ttk.Button(psutil,text="Install",command=lambda: module_install("psutil",psutil_label)).place(x=140,y=6)

orca = ttk.Labelframe(root,height=60,width=250,text='Orca')
orca.place(x=360,y=290)
orca_label = ttk.Label(orca,text="Please Install...")
orca_label.place(x=10,y=10)
ttk.Button(orca,text="Install",command=lambda: module_install("orca",orca_label)).place(x=140,y=6)

kaleido = ttk.Labelframe(root,height=60,width=250,text='Kaleido')
kaleido.place(x=660,y=290)
kaleido_label = ttk.Label(kaleido,text="Please Install...")
kaleido_label.place(x=10,y=10)
ttk.Button(kaleido,text="Install",command=lambda: module_install("kaleido",kaleido_label)).place(x=140,y=6)

root.mainloop()
