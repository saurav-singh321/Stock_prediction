from tkinter import *
from tkinter import ttk
import plotly.io as pio
from modules import range_selector
from tkinter import filedialog
import pandas as pd
import numpy as np
import datetime
import plotly.graph_objects as go
import os
import matplotlib.pyplot as plt
from PIL import Image, ImageTk
import sys
from cefpython3 import cefpython as cef
import platform
from modules import timelist
from modules import Auto_Arima
from modules import Arima
from pandastable import Table, TableModel
from tkinter import messagebox
from modules.installation import install

report_data,orginal_data = "",""

def graph_dash(entry_file,entry_csize):
    file_location = entry_file.get()
    duration = int(entry_csize.get())
    new_data,arrow_list = range_selector.range_selector(file_location,duration)
    
    fig = go.Figure(data = [go.Candlestick(
        x = new_data['TimeStamp'],
        open = new_data['Open'],
        high = new_data['High'],
        low = new_data['Low'],
        close = new_data['Close'],
        increasing_line_color = 'green',
        decreasing_line_color = 'red'
        )])

    fig.update_layout(
        title = new_data["ScriptName"][0],
        yaxis_title = "Stocks",
        xaxis_title = "Time Duration in Hours:Minutes:Seconds",
        annotations=arrow_list
        )
    pio.write_html(fig, file='extras/graph.html')

    page_location = "file:///{}/extras/graph.html".format(os.getcwd())
    page_location = page_location.replace("\\","/")
    #print(page_location)

    sys.excepthook = cef.ExceptHook
    cef.Initialize()
    cef.CreateBrowserSync(url=page_location,window_title = "Candlestick Graph Full Version")
    cef.MessageLoop()
    
    print("Graph Dash")

def file_name(entry_file):
    filename = filedialog.askopenfile()
    entry_file.insert(0,filename.name)

def folder_name(entry_folder,entry_script,combobox_timeto,combobox_timefrom,combobox_month,entry_join):
    foldername = filedialog.askdirectory()
    entry_folder.insert(0,foldername)
    folders = os.listdir(foldername)
    folders.sort()
    #print(folders)
    combobox_month.config(values = folders)
    time_list = timelist.time_list()
    combobox_timeto.config(values=time_list)
    combobox_timefrom.config(values=time_list)

def reset_report(entry_folder,entry_script,combobox_timeto,combobox_timefrom,combobox_month,combobox_join,model_name):
    entry_folder.delete(0,'end')
    entry_script.delete(0,'end')
    combobox_timeto.delete(0,'end')
    combobox_timefrom.delete(0,'end')
    combobox_month.delete(0,'end')
    combobox_join.delete(0,'end')

def graph_button_r(report_data,original_data):
    #print(report_data)
    #print(original_data)
    global root
    data_values = [i for i in original_data["Close"]]
    #print(data_values)
    #print(len(data_values))
    data_dates = [i for i in original_data["DateTime"]]
    #print(data_dates)
    pred_values = [i for i in original_data.loc[:len(original_data)-16,"Close"]]
    for i in report_data["Predicted"]:
        pred_values.append(i)
    pred_dates = [i for i in original_data.loc[:len(original_data)-16,"DateTime"]]
    for i in report_data["DateTime"]:
        pred_dates.append(i)
    fig = plt.figure()
    plt.plot(pred_dates,pred_values,color='red',marker='X',label='Predicted Value')
    plt.plot(data_dates,data_values,color='blue',marker='o',label='Data Value')
    plt.title('AUTO ARIMA MODEL')
    plt.xlabel('TimeStamp')
    plt.ylabel('Prices')
    fig.set_figheight(10)
    fig.set_figwidth(10)
    plt.legend()
    plt.savefig("extras/demo.jpeg",dpi=600,bbox_inches='tight')
    plt.show()
    print("Clicked and Clicked")

def submit_report(entry_folder,entry_script,combobox_timeto,combobox_timefrom,combobox_month,combobox_join,model_name,frame_sub_report_2,button_graph_r):
    print("Execution Ready!")
    global report_data
    global original_data
     #print(entry_folder.get())
    #print(entry_script.get())
    #print(combobox_timeto.get())
    #print(combobox_timefrom.get())
    #print(combobox_month.get())
    #print(int(combobox_join.get()))
    #print(model_name.get(),type(model_name.get()))
    #progressbar.config(mode='indeterminate')
    #progressbar.start()
    if model_name.get() == 1:
        report_data,original_data = Arima.report(entry_folder.get(),entry_script.get(),combobox_timefrom.get(),combobox_timeto.get(),combobox_month.get(),int(combobox_join.get()))
        pt = Table(frame_sub_report_2, dataframe=report_data,showtoolbar=True, showstatusbar=False)
        pt.show()
        messagebox.showinfo(title="Completion Box",message="Execution Completed! \nReport Generated!")
        button_graph_r.place(x=320, y=220)
        button_graph_r.config(command = lambda: graph_button_r(report_data,original_data))
    elif model_name.get() == 2:
        report_data,original_data = Auto_Arima.report(entry_folder.get(),entry_script.get(),combobox_timefrom.get(),combobox_timeto.get(),combobox_month.get(),int(combobox_join.get()))
        pt = Table(frame_sub_report_2, dataframe=report_data,showtoolbar=True, showstatusbar=False)
        pt.show()
        messagebox.showinfo(title="Completion Box",message="Execution Completed! \nReport Generated!")
        button_graph_r.place(x=320, y=220)
        button_graph_r.config(command = lambda: graph_button_r(report_data,original_data))
    else:
        messagebox.showinfo(title="Error",message="Choose the correct model please!")

def submit_graph(entry_file,entry_csize,frame_sub_graph_2):
    file_location = entry_file.get()
    duration = int(entry_csize.get())
    new_data,arrow_list = range_selector.range_selector(file_location,duration)
    
    fig = go.Figure(data = [go.Candlestick(
        x = new_data['TimeStamp'],
        open = new_data['Open'],
        high = new_data['High'],
        low = new_data['Low'],
        close = new_data['Close'],
        increasing_line_color = 'green',
        decreasing_line_color = 'red'
        )])

    fig.update_layout(
        title = new_data["ScriptName"][0],
        yaxis_title = "Stocks",
        xaxis_title = "Time Duration in Hours:Minutes:Seconds",
        annotations=arrow_list
        )
    
    fig.update_layout(xaxis_rangeslider_visible=False)

    if not os.path.exists("images"):
        os.mkdir("images")

    fig.write_image("images/{}_graph.jpeg".format(new_data["ScriptName"][0]))

    imageg = Image.open("images/{}_graph.jpeg".format(new_data["ScriptName"][0]))
    imageg = imageg.resize((950,520),Image.ANTIALIAS)
    test = ImageTk.PhotoImage(imageg)
    label1 = ttk.Label(frame_sub_graph_2,image=test)
    label1.image = test
    label1.place(x=7,y=0)

    print("CandleStick Graph SUBMIT")
    return label1

def reset_graph(entry_file,entry_csize):
    entry_file.delete(0,'end')
    entry_csize.delete(0,'end')
    print("CandleStick Graph RESET")

def module_install(package,label):
    result = install(package)
    label.config(text=result)

root = Tk()
root.title("Stock Market Report Generation")
root.geometry('1000x750+200+200')
root.resizable(0,0)

root.option_add('*tearOff', False)
menubar = Menu(root)
root.config(menu = menubar)
file = Menu(menubar)
edit = Menu(menubar)
help_ = Menu(menubar)

menubar.add_cascade(menu = file, label = 'File')
menubar.add_cascade(menu = edit, label = 'Edit')
menubar.add_cascade(menu = help_, label = 'Help')

notebook = ttk.Notebook(root)
notebook.pack()

frame_graph = ttk.Frame(root)
frame_graph.pack()
frame_graph.config(padding = (10,10))

frame_report = ttk.Frame(root)
frame_report.pack()

frame_install = ttk.Frame(root)
frame_install.pack()

notebook.add(frame_graph, text = "CandleStick Graph")
notebook.add(frame_report, text = "Report Generation")
notebook.add(frame_install, text = "Installation Check")

# Candlestick Graph
frame_sub_graph_1 = ttk.Labelframe(frame_graph,height=100,width=620,text='Input Box')
frame_sub_graph_1.pack()

frame_sub_graph_2 = ttk.Labelframe(frame_graph,height=550,width=990,text='Candlestick Graph')
frame_sub_graph_2.pack()

frame_sub_graph_3 = ttk.Labelframe(frame_graph,height=70,width=180,text='Candlestick Graph Full Version')
frame_sub_graph_3.pack()

label_file = ttk.Label(frame_sub_graph_1,text = "File Location:",font=("Arial",12))
label_file.place(x = 10, y = 10)

label_csize = ttk.Label(frame_sub_graph_1,text = "Candle Size (In minutes):",font=("Arial",12))
label_csize.place(x = 230, y = 10)

entry_file = ttk.Entry(frame_sub_graph_1,width=26)
entry_file.place(x=11,y=40)

entry_csize = ttk.Entry(frame_sub_graph_1,width=30)
entry_csize.place(x=231,y=40)

button_submit = ttk.Button(frame_sub_graph_1,text = "SUBMIT",)
button_submit.place(x=450, y=38)
button_submit.config(command = lambda: submit_graph(entry_file,entry_csize,frame_sub_graph_2))

button_reset = ttk.Button(frame_sub_graph_1,text = "RESET")
button_reset.place(x=530, y=38)
button_reset.config(command = lambda: reset_graph(entry_file,entry_csize))

file_logo_1 = PhotoImage(file="extras/Folder-icon.png").subsample(18,18)
button_file_location_1 = ttk.Button(frame_sub_graph_1,text="",width=1)
button_file_location_1.place(x=174,y=38)
button_file_location_1.config(image = file_logo_1)
button_file_location_1.config(command = lambda: file_name(entry_file))

button_reset = ttk.Button(frame_sub_graph_3,text = "Generate Candlestick Dash")
button_reset.place(x=12, y=0)
button_reset.config(command = lambda: graph_dash(entry_file,entry_csize))

# Report Generation
frame_sub_report_1 = ttk.Labelframe(frame_report,height=270,width=480,text='Input Box')
frame_sub_report_1.pack()

frame_sub_report_2 = ttk.Labelframe(frame_report,height=450,width=500,text='Report Visualization')
frame_sub_report_2.pack()

label_folder = ttk.Label(frame_sub_report_1,text = "Select Folder:",font=("Arial",12))
label_folder.place(x = 10, y = 10)
entry_folder = ttk.Entry(frame_sub_report_1,width=26)
entry_folder.place(x = 11 , y = 30)

label_script = ttk.Label(frame_sub_report_1,text = "Enter Script Name:",font=("Arial",12))
label_script.place(x = 300, y = 10)
entry_script = ttk.Entry(frame_sub_report_1,width=26)
entry_script.place(x = 301,y = 30)

label_timeto = ttk.Label(frame_sub_report_1,text = "Time to Start From:",font=("Arial",12))
label_timeto.place(x = 10, y = 70)
combobox_timefrom = ttk.Combobox(frame_sub_report_1,width=23)
combobox_timefrom.place(x=11,y=90)

label_timefrom = ttk.Label(frame_sub_report_1,text = "Time to End To:",font=("Arial",12))
label_timefrom.place(x = 300, y = 70)
combobox_timeto = ttk.Combobox(frame_sub_report_1,width=23)
combobox_timeto.place(x=301,y=90)

label_month = ttk.Label(frame_sub_report_1,text = "Select Month:",font=("Arial",12))
label_month.place(x = 10, y = 140)
combobox_month = ttk.Combobox(frame_sub_report_1,width=23)
combobox_month.place(x=11,y=160)

label_join = ttk.Label(frame_sub_report_1,text = "Number of Files to Join:",font=("Arial",12))
label_join.place(x = 300, y = 140)
entry_join = ttk.Entry(frame_sub_report_1,width=26)
entry_join.place(x=301,y=160)

model_name = IntVar()
ttk.Radiobutton(frame_sub_report_1,text="ARIMA Model",variable=model_name,value=1).place(x=15,y=200)
ttk.Radiobutton(frame_sub_report_1,text="AUTO ARIMA Model",variable=model_name,value=2).place(x=15,y=220)

button_graph_r = ttk.Button(frame_sub_report_1,text = "GENERATE GRAPH")

button_submit_r = ttk.Button(frame_sub_report_1,text = "SUBMIT",)
button_submit_r.place(x=300, y=185)
button_submit_r.config(command = lambda: submit_report(entry_folder,entry_script,combobox_timeto,combobox_timefrom,
                                                       combobox_month,entry_join,model_name,frame_sub_report_2,button_graph_r))

button_reset_r = ttk.Button(frame_sub_report_1,text = "RESET")
button_reset_r.place(x=385, y=185)
button_reset_r.config(command = lambda: reset_report(entry_folder,entry_script,combobox_timeto,combobox_timefrom,
                                                       combobox_month,entry_join,model_name))

file_logo_2 = PhotoImage(file="extras/Folder-icon.png").subsample(18,18)
button_file_location_2 = ttk.Button(frame_sub_report_1,text="",width=1)
button_file_location_2.place(x=174,y=28)
button_file_location_2.config(image = file_logo_2)
button_file_location_2.config(command = lambda: folder_name(entry_folder,entry_script,combobox_timeto,combobox_timefrom,combobox_month,entry_join))

#Installation
pandas = ttk.Labelframe(frame_install,height=60,width=250,text='Pandas')
pandas.place(x=60,y=10)
pandas_label = ttk.Label(pandas,text="Please Install...")
pandas_label.place(x=10,y=10)
ttk.Button(pandas,text="Install",command=lambda: module_install("pandas",pandas_label)).place(x=140,y=6)

numpy = ttk.Labelframe(frame_install,height=60,width=250,text='Numpy')
numpy.place(x=360,y=10)
numpy_label = ttk.Label(numpy,text="Please Install...")
numpy_label.place(x=10,y=10)
ttk.Button(numpy,text="Install",command=lambda: module_install("numpy",numpy_label)).place(x=140,y=6)

plotly = ttk.Labelframe(frame_install,height=60,width=250,text='Plotly')
plotly.place(x=660,y=10)
plotly_label = ttk.Label(plotly,text="Please Install...")
plotly_label.place(x=10,y=10)
ttk.Button(plotly,text="Install",command=lambda: module_install("plotly",plotly_label)).place(x=140,y=6)

matplotlib = ttk.Labelframe(frame_install,height=60,width=250,text='Matplotlib')
matplotlib.place(x=60,y=80)
matplotlib_label = ttk.Label(matplotlib,text="Please Install...")
matplotlib_label.place(x=10,y=10)
ttk.Button(matplotlib,text="Install",command=lambda: module_install("matplotlib",matplotlib_label)).place(x=140,y=6)

cefpython3 = ttk.Labelframe(frame_install,height=60,width=250,text='Cefpython3')
cefpython3.place(x=360,y=80)
cefpython3_label = ttk.Label(cefpython3,text="Please Install...")
cefpython3_label.place(x=10,y=10)
ttk.Button(cefpython3,text="Install",command=lambda: module_install("cefpython3",cefpython3_label)).place(x=140,y=6)

pandastable = ttk.Labelframe(frame_install,height=60,width=250,text='Pandastable')
pandastable.place(x=660,y=80)
pandastable_label = ttk.Label(pandastable,text="Please Install...")
pandastable_label.place(x=10,y=10)
ttk.Button(pandastable,text="Install",command=lambda: module_install("pandastable",pandastable_label)).place(x=140,y=6)

platform = ttk.Labelframe(frame_install,height=60,width=250,text='Platform')
platform.place(x=60,y=150)
platform_label = ttk.Label(platform,text="Please Install...")
platform_label.place(x=10,y=10)
ttk.Button(platform,text="Install",command=lambda: module_install("platform",platform_label)).place(x=140,y=6)

pillow = ttk.Labelframe(frame_install,height=60,width=250,text='Pillow')
pillow.place(x=360,y=150)
pillow_label = ttk.Label(pillow,text="Please Install...")
pillow_label.place(x=10,y=10)
ttk.Button(pillow,text="Install",command=lambda: module_install("pillow",pillow_label)).place(x=140,y=6)

statsmodel = ttk.Labelframe(frame_install,height=60,width=250,text='Statsmodel')
statsmodel.place(x=660,y=150)
statsmodel_label = ttk.Label(statsmodel,text="Please Install...")
statsmodel_label.place(x=10,y=10)
ttk.Button(statsmodel,text="Install",command=lambda: module_install("statsmodel",statsmodel_label)).place(x=140,y=6)

scipy = ttk.Labelframe(frame_install,height=60,width=250,text='Scipy')
scipy.place(x=60,y=220)
scipy_label = ttk.Label(scipy,text="Please Install...")
scipy_label.place(x=10,y=10)
ttk.Button(scipy,text="Install",command=lambda: module_install("scipy",scipy_label)).place(x=140,y=6)

sklearn = ttk.Labelframe(frame_install,height=60,width=250,text='Scikit Learn')
sklearn.place(x=360,y=220)
sklearn_label = ttk.Label(sklearn,text="Please Install...")
sklearn_label.place(x=10,y=10)
ttk.Button(sklearn,text="Install",command=lambda: module_install("scikit-learn",sklearn_label)).place(x=140,y=6)

pmdarima = ttk.Labelframe(frame_install,height=60,width=250,text='Pmdarima')
pmdarima.place(x=660,y=220)
pmdarima_label = ttk.Label(pmdarima,text="Please Install...")
pmdarima_label.place(x=10,y=10)
ttk.Button(pmdarima,text="Install",command=lambda: module_install("pmdarima",pmdarima_label)).place(x=140,y=6)

root.mainloop()
